import React from 'react'
export const SupabaseContext = React.createContext(null)
export const SupabaseProvider = SupabaseContext.Provider
export const useSupabase = () => React.useContext(SupabaseContext)
