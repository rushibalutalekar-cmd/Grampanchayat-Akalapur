import React from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import GramPanchayatAkalapur from './App.jsx'
import AdminLogin from './admin/AdminLogin.jsx'
import AdminDashboard from './admin/AdminDashboard.jsx'
import { createClient } from '@supabase/supabase-js'
import { SupabaseProvider } from './supabaseContext.jsx'

// Supabase placeholders: set REAL values in .env when deploying
const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || ''
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || ''

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY)

export default function AppRouter(){
  return (
    <SupabaseProvider value={{ supabase }}>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<GramPanchayatAkalapur />} />
          <Route path="/admin" element={<AdminLogin />} />
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          <Route path="*" element={<Navigate to='/' />} />
        </Routes>
      </BrowserRouter>
    </SupabaseProvider>
  )
}
