import React, { useState, useEffect } from "react";
import { Link } from 'react-router-dom';

// (DATA and UI objects same as before, Marathi default)
const DATA = {
  village: "Akalapur",
  sarpanch: { name: "Arun Tulshiram Wagh", phone: "+91-9975648034" },
  officer: { name: "R.M. Lahoti", phone: "+91-9373968243" },
  address: "Gram Panchayat Office, Akalapur, [Taluka], [District], Maharashtra, India, PIN",
  services: [
    "जन्म आणि मृत्यूशी संबंधित प्रमाणपत्र जारी करणे (Birth & Death Certificates)",
    "मालमत्ता व जमीन नोंदी संबंधित मदत (Property & Land Records Assistance)",
    "पेन्शन व कल्याण योजना नोंदणी (Pension & Welfare Scheme Registration)",
    "पाणी व स्वच्छता संबंधित विनंत्या (Water & Sanitation Requests)",
    "स्थानिक रस्त्यांचे बांधकाम व देखभाल (Road Construction & Maintenance)",
    "जनहित तक्रार निवारण (Public Grievance Redressal)",
    "आयकर / जाती प्रमाणपत्रासाठी सहाय्य (Income / Caste Certificate Support)",
  ],
  staff: [
    { name: "Balshiram Gaykawad", role: "शिपाई (Shipaee)", phone: "+91-9356787994" },
    { name: "Narayan Abhale", role: "पाणी व्यवस्थापन (Water Management)", phone: "+91-8796880460" },
    { name: "Rushi Talekar", role: "कॉम्प्युटर ऑपरेटर (Computer Operator)", phone: "+91-7822012052" },
    { name: "Ravi Madhe", role: "ग्राम रोजगार सेवक (Gram Rojgar Sevak)", phone: "+91-8459781488" },
  ],
  officeHours: "सोमवार - शनिवार: 10:00 AM - 5:00 PM",
  email: "gpakalapur58@gmail.com",
};

const UI = {
  en: {
    quickActions: "Quick Actions",
    servicesProvided: "Services Provided",
    staffDirectory: "Staff Directory",
    publicNotices: "Public Notices",
    callSarpanch: "Call Sarpanch",
    callOfficer: "Call GP Officer",
    emailOffice: "Email Office",
    noNotices: "No current notices."
  },
  mr: {
    quickActions: "जलद क्रिया",
    servicesProvided: "सेवा दिल्या जातात",
    staffDirectory: "कर्मचारी यादी",
    publicNotices: "सार्वजनिक सूचना",
    callSarpanch: "सार्पंच यांना कॉल करा",
    callOfficer: "ग्रामपंचायत अधिकाऱ्यांना कॉल करा",
    emailOffice: "कार्यालयाला ईमेल करा",
    noNotices: "सद्याच्या सूचना नाहीत."
  }
};

export default function GramPanchayatAkalapur() {
  const [language, setLanguage] = useState("mr");
  const [notices, setNotices] = useState([]);

  useEffect(() => {
    try { localStorage.setItem('gp_language', language); } catch(e){}
  }, [language]);

  useEffect(() => {
    try {
      const saved = localStorage.getItem('gp_language');
      if (saved) setLanguage(saved);
    } catch(e){}
  }, []);

  const t = (key) => UI[language]?.[key] || key;

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 antialiased">
      <header className="bg-white shadow">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex items-center justify-between">
          <div>
            <h1 className="text-2xl md:text-3xl font-semibold">Gram Panchayat — {DATA.village}</h1>
            <p className="text-sm text-gray-600">समुदायासाठी पारदर्शक व मदतनीस सेवाः</p>
          </div>
          <div className="space-x-3 flex items-center">
            <a href={`tel:${DATA.sarpanch.phone}`} className="inline-flex items-center px-4 py-2 border rounded-md text-sm font-medium hover:bg-gray-100">
              {t('callSarpanch')}
            </a>
            <a href={`tel:${DATA.officer.phone}`} className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700">
              {t('callOfficer')}
            </a>
            <Link to="/admin" className="ml-2 text-sm underline">Admin Login</Link>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-4 sm:p-6 lg:p-8">
        {/* Main content (services, staff, notices) same as previous implementation */}
        <section className="mb-8">
          <div className="bg-white rounded-2xl p-6 shadow">
            <h2 className="text-xl font-semibold mb-4">{t('servicesProvided')}</h2>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {DATA.services.map((s, i) => (
                <li key={i} className="p-3 border rounded">{s}</li>
              ))}
            </ul>
          </div>
        </section>

        <section className="mb-8">
          <div className="bg-white rounded-2xl p-6 shadow overflow-x-auto">
            <h2 className="text-xl font-semibold mb-4">{t('staffDirectory')}</h2>
            <table className="min-w-full text-sm">
              <thead>
                <tr className="text-left border-b">
                  <th className="py-2">नाव (Name)</th>
                  <th className="py-2">पद (Role)</th>
                  <th className="py-2">फोन (Phone)</th>
                </tr>
              </thead>
              <tbody>
                {DATA.staff.map((st, idx) => (
                  <tr key={idx} className="border-b last:border-0">
                    <td className="py-3">{st.name}</td>
                    <td className="py-3">{st.role}</td>
                    <td className="py-3"><a className="underline" href={`tel:${st.phone}`}>{st.phone}</a></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section className="mb-8">
          <div className="bg-white rounded-2xl p-6 shadow">
            <h2 className="text-xl font-semibold mb-4">{t('publicNotices')}</h2>
            <div className="text-sm text-gray-600">नोटिसेस साठी प्रशासनाच्या लॉगिनचा वापर करा.</div>
          </div>
        </section>

      </main>

      <footer className="bg-white border-t">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col md:flex-row items-center justify-between text-sm text-gray-600">
          <div>© {new Date().getFullYear()} Gram Panchayat {DATA.village}. सर्व हक्क राखीव.</div>
          <div className="mt-3 md:mt-0">Accessible • Mobile-friendly • संपर्क: <a href={`mailto:${DATA.email}`} className="underline">{DATA.email}</a></div>
        </div>
      </footer>
    </div>
  );
}
