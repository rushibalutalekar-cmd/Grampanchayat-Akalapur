import React, { useEffect, useState } from 'react'
import { useSupabase } from '../supabaseContext.jsx'
import { useNavigate } from 'react-router-dom'

export default function AdminDashboard(){
  const { supabase } = useSupabase()
  const [notices, setNotices] = useState([])
  const [newNotice, setNewNotice] = useState('')
  const [staff, setStaff] = useState([])
  const navigate = useNavigate()

  useEffect(()=>{ fetchData() }, [])

  async function fetchData(){
    // Fetch notices & staff from 'notices' and 'staff' tables (supabase)
    const { data: n, error: ne } = await supabase.from('notices').select('*').order('id', { ascending: false })
    if(n) setNotices(n)
    const { data: s } = await supabase.from('staff').select('*').order('id', { ascending: true })
    if(s) setStaff(s)
  }

  async function addNotice(){
    if(!newNotice.trim()) return
    await supabase.from('notices').insert([{ message: newNotice.trim() }])
    setNewNotice('')
    fetchData()
  }

  async function deleteNotice(id){
    await supabase.from('notices').delete().eq('id', id)
    fetchData()
  }

  async function signOut(){
    await supabase.auth.signOut()
    navigate('/')
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto bg-white p-6 rounded shadow">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Admin Dashboard</h2>
          <div className="space-x-2">
            <button onClick={signOut} className="text-sm underline">Sign out</button>
          </div>
        </div>

        <section className="mb-6">
          <h3 className="font-medium mb-2">Public Notices</h3>
          <div className="flex gap-2 mb-3">
            <input value={newNotice} onChange={(e)=>setNewNotice(e.target.value)} className="flex-1 border px-3 py-2 rounded" placeholder="Enter notice" />
            <button onClick={addNotice} className="bg-blue-600 text-white px-4 py-2 rounded">Add</button>
          </div>
          <ul className="space-y-2">
            {notices.map(n => (
              <li key={n.id} className="p-3 border rounded flex justify-between items-start">
                <div>{n.message}</div>
                <div><button onClick={()=>deleteNotice(n.id)} className="text-sm text-red-600">Delete</button></div>
              </li>
            ))}
            {notices.length===0 && <li className="text-sm text-gray-500">No notices yet.</li>}
          </ul>
        </section>

        <section>
          <h3 className="font-medium mb-2">Staff Directory</h3>
          <table className="min-w-full text-sm mb-4">
            <thead><tr className="border-b"><th className="py-2">Name</th><th>Role</th><th>Phone</th></tr></thead>
            <tbody>
              {staff.map(s => (
                <tr key={s.id} className="border-b">
                  <td className="py-2">{s.name}</td>
                  <td>{s.role}</td>
                  <td>{s.phone}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="text-xs text-gray-500">To update the staff list structure, use the Supabase table editor or contact the developer.</div>
        </section>

      </div>
    </div>
  )
}
