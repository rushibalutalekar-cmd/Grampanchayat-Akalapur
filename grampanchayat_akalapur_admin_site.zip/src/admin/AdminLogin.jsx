import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useSupabase } from '../supabaseContext.jsx'

export default function AdminLogin(){
  const { supabase } = useSupabase()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState(null)
  const navigate = useNavigate()

  const signIn = async () => {
    setError(null)
    if(!email || !password) { setError('Enter email and password'); return }
    // Supabase auth signInWithPassword
    const { data, error } = await supabase.auth.signInWithPassword({ email, password })
    if(error){ setError(error.message); return }
    // On success redirect to dashboard
    navigate('/admin/dashboard')
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="bg-white p-6 rounded shadow w-full max-w-md">
        <h2 className="text-xl font-semibold mb-4">Admin Login</h2>
        <div className="mb-2">
          <label className="text-sm">Email</label>
          <input className="w-full border px-3 py-2 rounded" value={email} onChange={(e)=>setEmail(e.target.value)} />
        </div>
        <div className="mb-4">
          <label className="text-sm">Password</label>
          <input type="password" className="w-full border px-3 py-2 rounded" value={password} onChange={(e)=>setPassword(e.target.value)} />
        </div>
        {error && <div className="text-sm text-red-600 mb-2">{error}</div>}
        <button onClick={signIn} className="bg-blue-600 text-white px-4 py-2 rounded">Login</button>
      </div>
    </div>
  )
}
