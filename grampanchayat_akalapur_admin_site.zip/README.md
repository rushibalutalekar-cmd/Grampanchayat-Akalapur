# Gram Panchayat Akalapur — Admin-enabled Website (React + Vite + Tailwind + Supabase)

This project provides the public site and a simple admin dashboard at `/admin`.  
**Default site language:** Marathi (can toggle to English).

## Overview

- Public site: `/`
- Admin login: `/admin`
- Admin dashboard: `/admin/dashboard`
- Admin tasks: Add/Edit/Delete public notices, view staff list.

## IMPORTANT — Supabase Setup (required)

This project uses **Supabase** for authentication and data storage. No admin accounts are included in the repo for security — **you must add admin users yourself**.

### 1) Create a Supabase project
1. Sign up / sign in at https://supabase.com
2. Create a new project (choose free tier)
3. In the project dashboard, go to **Settings → API** and copy:
   - `Project URL` → VITE_SUPABASE_URL
   - `anon public` → VITE_SUPABASE_ANON_KEY

### 2) Create required tables
Open **SQL Editor** in Supabase and run the following to create tables:

```sql
create table if not exists notices (
  id bigint generated always as identity primary key,
  message text,
  inserted_at timestamptz default now()
);

create table if not exists staff (
  id bigint generated always as identity primary key,
  name text,
  role text,
  phone text
);
```

### 3) Add Admin Users (no logins included)
From the Supabase dashboard:
- Go to **Authentication → Users**.
- Create users for:
  - Sarpanch (use Sarpanch's real email)
  - Rushi Talekar (use Rushi's real email)

Set their passwords in the Supabase UI (they'll use these credentials to log in).

> NOTE: For security, use real email addresses and communicate passwords privately.

### 4) Configure project locally
1. Copy `.env.example` to `.env`
2. Paste your Supabase URL and anon key into `.env`
3. Run:
```bash
npm install
npm run dev
```

### 5) Deploy to Vercel
1. Push the repo to GitHub.
2. On Vercel, import the repo and set environment variables (VITE_SUPABASE_URL & VITE_SUPABASE_ANON_KEY) in the Vercel project settings.
3. Deploy.

## Security notes
- Do not commit your `.env` with keys to GitHub.
- Use secure passwords and change them if leaked.
- Consider enabling row-level security (RLS) and policies in Supabase if you want more granular access control.

## Contact
Site contact: gpakalapur58@gmail.com
