# 🌾 Gram Panchayat Akalapur Website

This is the official website for **Gram Panchayat Akalapur**, built using **React + Vite + Tailwind CSS**.  
Default language: **Marathi**, with option to switch to **English**.

---

## 🧭 Features

- 📞 Contact info for Sarpanch, GP Officer, and staff
- 🧾 Services list & office details
- 📢 Public notices section (demo editable)
- 🌐 Multilingual (Marathi ↔ English)
- 📱 Fully mobile-friendly design

---

## 🚀 Quick Start (Local Setup)

1. **Extract the ZIP** and open the folder in VS Code or any terminal.
2. Run the following commands:

```bash
npm install
npm run dev
```

Your local site will run on [http://localhost:5173](http://localhost:5173).

---

## 🌍 Deploy Online (Recommended: Vercel)

### 🔹 One-click Deploy

Click the button below to instantly deploy your site to Vercel (free hosting).

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/import/project?template=https://github.com/YOUR-GITHUB-USERNAME/grampanchayat-akalapur)

> ⚠️ Replace `YOUR-GITHUB-USERNAME` in the link above once you upload the project.

### 🔹 Manual Deploy (Steps)

1. Create a **GitHub repository** (e.g., `grampanchayat-akalapur`).
2. Upload all project files (or push via terminal):

```bash
git init
git add .
git commit -m "Initial commit for Gram Panchayat Akalapur website"
git branch -M main
git remote add origin https://github.com/YOUR-GITHUB-USERNAME/grampanchayat-akalapur.git
git push -u origin main
```

3. Go to [Vercel.com](https://vercel.com), click **“New Project” → “Import from GitHub”**, and select your repo.
4. Vercel will auto-detect Vite + React and deploy your site! ✅

Your site will go live at:  
👉 **https://grampanchayat-akalapur.vercel.app** (or your custom domain)

---

## 📁 GitHub Setup Notes

Include this `.gitignore` file in your project root:

```
node_modules
dist
.env
.DS_Store
.vscode
```
---

## 📬 Contact Info

- **Sarpanch:** Arun Tulshiram Wagh — 📞 9975648034  
- **Gram Panchayat Officer:** R.M. Lahoti — 📞 9373968243  
- **Email:** gpakalapur58@gmail.com  
- **Village:** Akalapur, Maharashtra

---

© 2025 Gram Panchayat Akalapur. All rights reserved.
