import React, { useState, useEffect } from "react";

// -------------------- GRAMPANCHAYAT AKALAPUR DATA --------------------
const DATA = {
  village: "Akalapur",
  sarpanch: {
    name: "Arun Tulshiram Wagh",
    phone: "+91-9975648034",
  },
  officer: {
    name: "R.M. Lahoti",
    phone: "+91-9373968243",
  },
  address: "Gram Panchayat Office, Akalapur, [Taluka], [District], Maharashtra, India, PIN",
  services: [
    "जन्म आणि मृत्यूशी संबंधित प्रमाणपत्र जारी करणे (Birth & Death Certificates)",
    "मालमत्ता व जमीन नोंदी संबंधित मदत (Property & Land Records Assistance)",
    "पेन्शन व कल्याण योजना नोंदणी (Pension & Welfare Scheme Registration)",
    "पाणी व स्वच्छता संबंधित विनंत्या (Water & Sanitation Requests)",
    "स्थानिक रस्त्यांचे बांधकाम व देखभाल (Road Construction & Maintenance)",
    "जनहित तक्रार निवारण (Public Grievance Redressal)",
    "आयकर / जाती प्रमाणपत्रासाठी सहाय्य (Income / Caste Certificate Support)",
  ],
  staff: [
    { name: "Balshiram Gaykawad", role: "शिपाई (Shipaee)", phone: "+91-9356787994" },
    { name: "Narayan Abhale", role: "पाणी व्यवस्थापन (Water Management)", phone: "+91-8796880460" },
    { name: "Rushi Talekar", role: "कॉम्प्युटर ऑपरेटर (Computer Operator)", phone: "+91-7822012052" },
    { name: "Ravi Madhe", role: "ग्राम रोजगार सेवक (Gram Rojgar Sevak)", phone: "+91-8459781488" },
  ],
  officeHours: "सोमवार - शनिवार: 10:00 AM - 5:00 PM",
  email: "gpakalapur58@gmail.com",
};

// Simple translations for UI strings
const UI = {
  en: {
    quickActions: "Quick Actions",
    servicesProvided: "Services Provided",
    staffDirectory: "Staff Directory",
    publicNotices: "Public Notices",
    callSarpanch: "Call Sarpanch",
    callOfficer: "Call GP Officer",
    emailOffice: "Email Office",
    noNotices: "No current notices."
  },
  mr: {
    quickActions: "जलद क्रिया",
    servicesProvided: "सेवा दिल्या जातात",
    staffDirectory: "कर्मचारी यादी",
    publicNotices: "सार्वजनिक सूचना",
    callSarpanch: "सार्पंच यांना कॉल करा",
    callOfficer: "ग्रामपंचायत अधिकाऱ्यांना कॉल करा",
    emailOffice: "कार्यालयाला ईमेल करा",
    noNotices: "सद्याच्या सूचना नाहीत."
  }
};

export default function GramPanchayatAkalapur() {
  // Default language = Marathi (mr)
  const [language, setLanguage] = useState("mr");
  const [notices, setNotices] = useState([]);

  // Persist language preference (optional)
  useEffect(() => {
    try { localStorage.setItem('gp_language', language); } catch(e){}
  }, [language]);

  useEffect(() => {
    try {
      const saved = localStorage.getItem('gp_language');
      if (saved) setLanguage(saved);
    } catch(e){}
  }, []);

  const t = (key) => UI[language]?.[key] || key;

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 antialiased">
      <header className="bg-white shadow">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex items-center justify-between">
          <div>
            <h1 className="text-2xl md:text-3xl font-semibold">Gram Panchayat — {DATA.village}</h1>
            <p className="text-sm text-gray-600">समुदायासाठी पारदर्शक व मदतनीस सेवाः</p>
          </div>
          <div className="space-x-3 flex items-center">
            <a href={`tel:${DATA.sarpanch.phone}`} className="inline-flex items-center px-4 py-2 border rounded-md text-sm font-medium hover:bg-gray-100">
              {t('callSarpanch')}
            </a>
            <a href={`tel:${DATA.officer.phone}`} className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700">
              {t('callOfficer')}
            </a>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-4 sm:p-6 lg:p-8">
        <div className="flex justify-end mb-4 items-center gap-3">
          <label className="text-sm text-gray-600">भाषा / Language:</label>
          <select
            className="border rounded px-2 py-1 text-sm"
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
          >
            <option value="mr">मराठी (Marathi)</option>
            <option value="en">English</option>
          </select>
        </div>

        <section className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="col-span-2 bg-white rounded-2xl p-6 shadow">
            <h2 className="text-xl font-semibold mb-4">महत्वाच्या संपर्कांची यादी</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <ContactCard title="सार्पंच" person={DATA.sarpanch} />
              <ContactCard title="ग्रामपंचायत अधिकारी" person={DATA.officer} />
            </div>

            <div className="mt-6">
              <h3 className="text-md font-medium">कार्यालय</h3>
              <p className="text-sm text-gray-600">{DATA.address}</p>
              <p className="text-sm text-gray-600">वेळ: {DATA.officeHours}</p>
              <p className="text-sm text-gray-600">ईमेल: <a href={`mailto:${DATA.email}`} className="underline">{DATA.email}</a></p>
            </div>
          </div>

          <aside className="bg-white rounded-2xl p-6 shadow">
            <h3 className="text-lg font-semibold mb-3">{t('quickActions')}</h3>
            <ul className="space-y-2">
              <li>
                <a className="block p-3 border rounded hover:bg-gray-50" href={`tel:${DATA.sarpanch.phone}`}>{t('callSarpanch')}</a>
              </li>
              <li>
                <a className="block p-3 border rounded hover:bg-gray-50" href={`tel:${DATA.officer.phone}`}>{t('callOfficer')}</a>
              </li>
              <li>
                <a className="block p-3 border rounded hover:bg-gray-50" href={`mailto:${DATA.email}`}>{t('emailOffice')}</a>
              </li>
            </ul>
          </aside>
        </section>

        <section className="mb-8">
          <div className="bg-white rounded-2xl p-6 shadow">
            <h2 className="text-xl font-semibold mb-4">{t('servicesProvided')}</h2>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {DATA.services.map((s, i) => (
                <li key={i} className="p-3 border rounded">{s}</li>
              ))}
            </ul>
          </div>
        </section>

        <section className="mb-8">
          <div className="bg-white rounded-2xl p-6 shadow overflow-x-auto">
            <h2 className="text-xl font-semibold mb-4">{t('staffDirectory')}</h2>
            <table className="min-w-full text-sm">
              <thead>
                <tr className="text-left border-b">
                  <th className="py-2">नाव (Name)</th>
                  <th className="py-2">पद (Role)</th>
                  <th className="py-2">फोन (Phone)</th>
                </tr>
              </thead>
              <tbody>
                {DATA.staff.map((st, idx) => (
                  <tr key={idx} className="border-b last:border-0">
                    <td className="py-3">{st.name}</td>
                    <td className="py-3">{st.role}</td>
                    <td className="py-3"><a className="underline" href={`tel:${st.phone}`}>{st.phone}</a></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section className="mb-8">
          <div className="bg-white rounded-2xl p-6 shadow">
            <h2 className="text-xl font-semibold mb-4">{t('publicNotices')}</h2>
            <PublicNoticeSection notices={notices} setNotices={setNotices} noNoticesText={t('noNotices')} />
          </div>
        </section>

      </main>

      <footer className="bg-white border-t">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col md:flex-row items-center justify-between text-sm text-gray-600">
          <div>© {new Date().getFullYear()} Gram Panchayat {DATA.village}. सर्व हक्क राखीव.</div>
          <div className="mt-3 md:mt-0">Accessible • Mobile-friendly • संपर्क: <a href={`mailto:${DATA.email}`} className="underline">{DATA.email}</a></div>
        </div>
      </footer>
    </div>
  );
}

function ContactCard({ title, person }) {
  return (
    <div className="p-4 border rounded-lg">
      <h4 className="text-sm font-medium text-gray-700">{title}</h4>
      <p className="mt-2 font-semibold">{person.name}</p>
      <p className="text-sm text-gray-600">Phone: <a href={`tel:${person.phone}`} className="underline">{person.phone}</a></p>
    </div>
  );
}

function PublicNoticeSection({ notices, setNotices, noNoticesText }) {
  const [newNotice, setNewNotice] = useState("");

  const addNotice = () => {
    if (!newNotice.trim()) return;
    setNotices([...notices, newNotice.trim()]);
    setNewNotice("");
  };

  return (
    <div>
      <div className="mb-4 flex gap-2">
        <input
          type="text"
          value={newNotice}
          onChange={(e) => setNewNotice(e.target.value)}
          placeholder="नवीन सूचना येथे टाका (केवळ प्रशासनासाठी)"
          className="border px-3 py-2 flex-1 rounded"
        />
        <button onClick={addNotice} className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">जोडा / Add</button>
      </div>
      <ul className="space-y-2">
        {(!notices || notices.length === 0) && <li className="text-sm text-gray-500">{noNoticesText}</li>}
        {notices && notices.map((n,i) => <li key={i} className="p-3 border rounded bg-gray-50">{n}</li>)}
      </ul>
    </div>
  );
}
